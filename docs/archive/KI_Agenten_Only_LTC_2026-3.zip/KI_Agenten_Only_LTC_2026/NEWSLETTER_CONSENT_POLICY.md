# NEWSLETTER CONSENT POLICY – LifeTimeCircle / Service Heft 4.0

Version: 1.0  
Stand: 2026-01-27  
Owner: SUPERADMIN

---

## 1) Regel (Non-Negotiable)
Newsletter ist ein separater Opt-In.  
Er darf nicht automatisch aus AGB/Datenschutz-Zustimmung abgeleitet werden.

---

## 2) Pflichtdaten (serverseitig)
- newsletter_consent (true/false)
- consent_timestamp
- consent_source (web/app/admin)
- consent_text_version

---

## 3) Unsubscribe
- jederzeit möglich, 1 Klick, sofort wirksam
- unsub erzeugt Audit-Event (ohne PII im Log)

---

## 4) Logging
- keine vollständige E-Mail in Logs
- nur email_hash oder interne user_id

---
